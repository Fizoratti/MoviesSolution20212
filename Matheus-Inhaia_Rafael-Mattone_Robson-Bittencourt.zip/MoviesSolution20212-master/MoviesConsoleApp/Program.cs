﻿using Microsoft.EntityFrameworkCore;
using Persistencia.Entidades;
using Persistencia.Repositorio;
using System;
using System.Collections.Generic;
using System.Linq;

namespace MoviesConsoleApp
{
    class Program
    {
        static void Main(String[] args)
        {
            MovieContext _db = new MovieContext();

            Console.WriteLine();
            Console.WriteLine("1. Listar o nome de todos personagens desempenhados por um determinado ator, incluindo a informação de qual o título do filme e o diretor");
            using (MovieContext _context = new MovieContext())
            {
                var obj1 = _context.Characters.Where(c => c.Actor.Name.Contains("Daniel Craig"))
                        .Include(c => c.Movie)
                        .ThenInclude(g => g.Genre)
                        .Select(c => new
                        {
                            Titulo_Filme = c.Movie.Title,
                            Nome_diretor = c.Movie.Director,
                            Nome_personagem = c.Character,
                        });

                foreach (Object filme in obj1)
                {
                    Console.WriteLine($"{filme}");
                }
            }

            Console.WriteLine();
            Console.WriteLine("2. Mostrar o nome e idade de todos atores que desempenharam um determinado personagem(por exemplo, quais os atores que já atuaram como '007' ?");
            using (MovieContext _context = new MovieContext())
            {
                var obj1 = _context.Characters
                               .Where(c => c.Character == "James Bond")
                               .Select(c => new
                               {
                                   Ator = c.Actor.Name,
                                   Idade = 2021 - c.Actor.DateBirth.Year 
                               }).Distinct();

                foreach (Object filme in obj1)
                {
                    Console.WriteLine($"{filme}");
                }
            }



            Console.WriteLine();
            Console.WriteLine("3. Informar qual o ator desempenhou mais vezes um determinado personagem(por exemplo: qual o ator que realizou mais filmes como o 'agente 007'");
            using (MovieContext _context = new MovieContext())
            {
                var obj1 = _context.Characters
                         .Where(character => character.Character == "James Bond")
                         .GroupBy(group => group.Actor.Name) 
                         .Select(select => new
                         {
                             Nome_Ator = select.Key,
                             Qtd_personagens = select.Select(character => character.Character).Count()
                         })
                         .OrderByDescending(actorQtd => actorQtd.Qtd_personagens).FirstOrDefault();

                Console.WriteLine($"{obj1}");
            }


            Console.WriteLine();
            Console.WriteLine("4. Mostrar o nome e a data de nascimento do ator mais idoso");
            using (MovieContext _context = new MovieContext())
            {
                var ator_idoso = (from a in _context.Actors
                                  orderby a.DateBirth
                                  select new { a.Name, a.DateBirth }
                                  ).FirstOrDefault();

                Console.WriteLine($"Ator mais velho: {ator_idoso.Name} nasceu em: {ator_idoso.DateBirth.ToString("dd/MM/yyyy")}.");
            }




            Console.WriteLine();
            Console.WriteLine("5. Mostrar o nome e a data de nascimento do ator mais novo a atuar em um determinado gênero");
            using (MovieContext _context = new MovieContext())
            {
                var ator = (from g in _context.Genres
                            join m in _context.Movies on g.GenreId equals m.GenreID
                            join ch in _context.Characters on m.MovieId equals ch.MovieId
                            join ac in _context.Actors on ch.ActorId equals ac.ActorId
                            where g.Name == "Action"
                            orderby ac.DateBirth descending
                            select new { ac.Name, ac.DateBirth, nome = g.Name}).FirstOrDefault();

                Console.WriteLine($"Ator mais jovem do genero {ator.nome} é: {ator.Name} nasceu em: {ator.DateBirth.ToString("dd/MM/yyyy")}.");
            }


            Console.WriteLine();
            Console.WriteLine("6. Mostrar o valor médio das avaliações dos filmes de um determinado ator diretor");
            using (MovieContext _context = new MovieContext())
            {
                var media = (from m in _context.Movies
                            where m.Director == "Martin Campbell"
                            select m.Rating).Average();

                Console.WriteLine($"O valor médio das avaliações dos filmes do diretor Martin Campbell é {media}.");
            }


            Console.WriteLine();
            Console.WriteLine("7. Qual o elenco do filme pior avaliado ?");
            using (MovieContext _context = new MovieContext())
            {
                var resposta = (from m in _context.Movies
                                join ch in _context.Characters on m.MovieId equals ch.MovieId
                                join ac in _context.Actors on ch.ActorId equals ac.ActorId
                                orderby m.Rating ascending
                                select new { m.Title, ac.Name });

                foreach (var elenco in resposta)
                {
                    Console.WriteLine($"Ator: {elenco.Name}");
                }
            }

            Console.WriteLine();
            Console.WriteLine("8. Qual o elenco do filme com o maior faturamento?");
            using (MovieContext _context = new MovieContext())
            {
                var filme = (from mo in _context.Movies
                             orderby mo.Gross
                             select new { mo.MovieId, mo.Gross, mo.Title }).FirstOrDefault();

                Console.WriteLine("Menor faturamento: " + filme.Gross + ", filme: ");

                var filmeMaiorFat = (from mo in _context.Movies
                                     join ch in _context.Characters on mo.MovieId equals ch.MovieId
                                     join ac in _context.Actors on ch.ActorId equals ac.ActorId
                                     where mo.MovieId == 23
                                     select new { ac.Name, ch.Character });

                Console.WriteLine();
                Console.WriteLine($"Filme com pior faturamento {filme.Title}");
                foreach (var cast in filmeMaiorFat)
                {
                    Console.WriteLine($"Ator: {cast.Name} - Personagem: {cast.Character}.");
                }
            }

        }
    }
}
